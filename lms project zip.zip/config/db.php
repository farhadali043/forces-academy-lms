<?php
$host='sql303.infinityfree.com';
$user='if0_42506971';
$password='farhadramish';
$database='if0_42506971_farhad';
$conn=mysqli_connect($host,$user,$password,$database);
if(!$conn){ die('Database connection failed: '.mysqli_connect_error()); }
?>